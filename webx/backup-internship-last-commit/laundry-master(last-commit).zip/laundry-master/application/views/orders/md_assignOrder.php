<div class="container-fluid">
    <div class="form-group row">
        <label class="col-md-3 col-form-label text-right">Order Id</label> 
        <label id="order_id" class="col-md-9 col-form-label"></label>
        <br>
    </div>
    <div class="form-group row">
        <label class="col-md-3 col-form-label text-right">Assign order</label>  
        
        <div class="col-md-9">
            <select id="employeeDropdown" class="form-control"></select>  
        </div>
    </div>
    <div class="form-group row text-primary text-center">
        <label class="status" id="status"></label>
    </div>
</div>