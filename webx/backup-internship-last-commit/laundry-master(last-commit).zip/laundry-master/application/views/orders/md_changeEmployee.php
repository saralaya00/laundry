<div class="container-fluid">
    <div class="form-group row">
        <label class="col-md-12 col-form-label">Order ID <span id="change_order_id" class="text-danger"></span> has been assigned to <span class="text-primary" id="employee_name"></span></label>  
        <br>
    </div>
    <div class="form-group row">
        <select class="form-control" id="changeEmployeeDropdown">

        </select>  
    </div>
    <div class="form-group row text-primary text-center">
        <label class="status" id="status"></label>
    </div>
</div>