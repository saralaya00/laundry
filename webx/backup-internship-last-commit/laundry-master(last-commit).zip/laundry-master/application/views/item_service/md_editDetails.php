<div class="container-fluid">
<div class="form-group row">
        <div class="col-md-12">
            <label class="col-form-label text-left current_status">Current Price is Rs.<span id="c_price"></span> </label> 
        </div>
    </div>
    <div class="form-group row justify-content-center">
    </div>
    <div class="form-group-12">
    </div>
    <div class="form-group row">
             <label class="col-md-3 col-form-label text-left">Edit price </label>
            <div class="col-md-4">
                <input type="text" id="price" class="form-control price">
            </div>
    </div>

    <div class="form-group row">
        <div class="col-md-12">
            <label class="col-form-label text-left status">Update price Rs.<span id="u_price"></span> </label> 
        </div>
    </div>
</div>
<script type="text/javascript">
 $(document).ready(function(){
   
    $(".status").hide();
 });



</script>