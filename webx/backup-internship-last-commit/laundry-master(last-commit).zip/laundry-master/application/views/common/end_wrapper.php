        </div>
    </div>
    <!-- (-) Page Wrapper : Container/Body -->
    
    <!-- Datatables.js -->
    <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
    <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>
    <!-- Custom JS -->
    <script src="assets/js/common.js"></script>
    <!-- <script src="assets/js/order.js"></script> -->
    <!-- <script src="assets/js/item_service.js"></script> -->
    <!--<script src="assets/js/bootbox.min.js"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.min.js"></script>
    
</body>
</html>