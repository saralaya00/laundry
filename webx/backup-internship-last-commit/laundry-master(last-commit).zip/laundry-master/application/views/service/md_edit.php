<div class="container-fluid">
    <div class="form-group row justify-content-center">
        <div class="form-group-12">
            <label class="col-md-3 col-form-label text-left">Edit service Name </label>
                <div class="col-md-4">
                    <input type="text" id="service_name" class="form-control service_name">
                </div>
        </div>
    </div>
</div>
