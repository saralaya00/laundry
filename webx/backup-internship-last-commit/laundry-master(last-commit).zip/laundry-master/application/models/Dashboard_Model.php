<?php 
    class Dashboard_Model extends CI_Model
    {
        public function __construct()
        {
            parent::__construct();
            $this->load->database();
        }

        //Feedback Module
    }
    
?>