# laundry
Laundry Automation System Webapp using PHP (Code Igniter), Bootstrap and jQuery.

Synopsis file:
https://docs.google.com/document/d/1vplvvIIHdrCUy199ncJsGV9H7BAnRPjO6n0uXLDXFAI/edit
